# Alkame-Nifty50

NIFTY 50 intraday market intelligence engine — human-in-the-loop, calibration-gated, event-aware.

Read `ALKAME_NIFTY50_CHARTER.md` first — it's the full methodology, regulatory, and business charter for this product, and explains *why* the system is built the way it is (risk-first, HOLD-with-reason as a valid output, calibration before confidence is ever shown, etc.).

## 1. Setup

**Requires Python 3.10+.**

```bash
pip install -r requirements.txt
```

Set your marketaux API key (get a free one at https://www.marketaux.com) as an environment variable — never hardcode it into any file:

```bash
export MARKETAUX_API_KEY="your_key_here"       # macOS/Linux
set MARKETAUX_API_KEY=your_key_here             # Windows (cmd)
$env:MARKETAUX_API_KEY="your_key_here"          # Windows (PowerShell)
```

Optional: `IMD_API_KEY` for live monsoon data (register at https://api.imd.gov.in). Without it, monsoon status falls back to manual entry via `macro_calendar.py`.

## 2. Verify everything works (recommended before first real use)

Each file has a self-test. Run them in order — they're fast (a few seconds each) except `data_fetcher.py`, `corporate_events_fetcher.py`, `news_sentiment_fetcher.py`, `global_risk_monitor.py`, `predictor.py`, and `scheduler.py`, which touch live external services and may take up to a minute or two:

```bash
python config.py
python macro_calendar.py
python data_fetcher.py
python corporate_events_fetcher.py    # run from a home/office connection — NSE blocks many cloud/VPN IPs
python news_sentiment_fetcher.py
python event_classifier.py
python global_risk_monitor.py
python feature_engineer.py
python model_trainer.py
python ensemble_manager.py
python runtime_validator.py
python predictor.py
python human_insight_manager.py
python history_manager.py
python backtester.py
python scheduler.py
python app.py                          # pure-logic self-test only; see step 3 for the real dashboard
```

Each prints `STATUS: PASS` or `STATUS: FAIL` at the end.

## 3. Run it

**Terminal 1 — the signal scheduler** (fetches data, generates signals, persists history):
```bash
python scheduler.py
```
Note: `scheduler.py` as delivered exposes the `Scheduler` class and its self-test; wire up `run_forever()` with a real `symbol_data_provider` callable (using `data_fetcher.py`) once you're ready to run it continuously — this is intentionally left as an integration point rather than a hardcoded always-on loop, since your actual symbol list, refresh cadence, and error-handling preferences for unattended operation are worth deciding deliberately.

**Terminal 2 — the dashboard:**
```bash
streamlit run app.py
```

## 4. Before showing this to anyone outside your own trading team

Read Section 9 of `ALKAME_NIFTY50_CHARTER.md` and talk to SEBI-registered securities counsel. Distributing signals to any third party — even for free — very likely requires Research Analyst registration under current SEBI regulations. This is not optional legal housekeeping; it's the single most important gate before any public launch.

## 5. Project structure

| File | Purpose |
|---|---|
| `config.py` | Central configuration — tickers, sectors, thresholds, paths |
| `macro_calendar.py` | RBI/Budget/election/festive calendar (human-maintained CSV) |
| `data_fetcher.py` | yfinance OHLCV data with retry + cache fallback |
| `corporate_events_fetcher.py` | NSE corporate announcements, board meetings, actions, block/bulk deals |
| `news_sentiment_fetcher.py` | marketaux + Google News RSS sentiment |
| `event_classifier.py` | Unifies all events, tags scope (MARKET/SECTOR/STOCK) |
| `global_risk_monitor.py` | Always-on composite risk score + human-gated toggle |
| `feature_engineer.py` | Technical indicators, strict no-lookahead discipline |
| `model_trainer.py` | Per-stock direction classifier, time-based split |
| `ensemble_manager.py` | Multi-model soft-voting ensemble with agreement scoring |
| `runtime_validator.py` | Calibration + edge-vs-NIFTY checks — the safety gate |
| `predictor.py` | Combines everything into one final BUY/SELL/HOLD signal |
| `human_insight_manager.py` | Trader notes, overrides, feedback (SQLite) |
| `history_manager.py` | Persists predictions/events, resolves outcomes (SQLite) |
| `backtester.py` | Historical replay with slippage/costs, real alpha calculation |
| `scheduler.py` | Orchestrates the full pipeline on a market-hours loop |
| `app.py` | Streamlit dashboard |

## 6. Known limitations to revisit

- NIFTY50 constituent list and sector map need verification against NSE's next semi-annual index review.
- Festive-window dates are approximate (lunar calendar shifts yearly) — verify each year.
- Exchange holidays aren't yet modeled in `scheduler.is_market_open()` — it currently only checks weekday + time window.
- `corporate_events_fetcher.py` may be blocked from cloud/VPN IPs by NSE's bot protection — run from a normal home connection.
